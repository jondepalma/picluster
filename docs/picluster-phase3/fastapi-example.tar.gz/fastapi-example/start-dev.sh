#!/bin/bash

# ============================================================================
# Development Startup Script
# ============================================================================
# This script sets up port-forwarding and starts the FastAPI application
# Run this on pi-worker-1 (10.0.0.11)

set -e

echo "=========================================="
echo "Pi Cluster API - Development Setup"
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if kubectl is configured
if ! kubectl cluster-info &> /dev/null; then
    echo -e "${RED}✗ kubectl is not configured${NC}"
    echo "Run the following to configure kubectl:"
    echo "  scp pi@10.0.0.10:/etc/rancher/k3s/k3s.yaml ~/.kube/config"
    echo "  sed -i 's/127.0.0.1/10.0.0.10/g' ~/.kube/config"
    exit 1
fi

echo -e "${GREEN}✓ kubectl is configured${NC}"

# Check if port-forwarding is already running
POSTGRES_PF=$(ps aux | grep "kubectl port-forward.*postgresql-dev" | grep -v grep || true)
SCYLLA_PF=$(ps aux | grep "kubectl port-forward.*scylla-dev" | grep -v grep || true)

# Kill existing port-forwards
if [ ! -z "$POSTGRES_PF" ]; then
    echo -e "${YELLOW}Stopping existing PostgreSQL port-forward...${NC}"
    pkill -f "kubectl port-forward.*postgresql-dev" || true
fi

if [ ! -z "$SCYLLA_PF" ]; then
    echo -e "${YELLOW}Stopping existing ScyllaDB port-forward...${NC}"
    pkill -f "kubectl port-forward.*scylla-dev" || true
fi

sleep 2

# Start port-forwarding
echo ""
echo "Starting port-forwards..."

# PostgreSQL
echo -e "${YELLOW}Port-forwarding PostgreSQL (localhost:5432)...${NC}"
kubectl port-forward -n dev svc/postgresql-dev 5432:5432 > /dev/null 2>&1 &
POSTGRES_PID=$!
sleep 2

if ps -p $POSTGRES_PID > /dev/null; then
    echo -e "${GREEN}✓ PostgreSQL port-forward running (PID: $POSTGRES_PID)${NC}"
else
    echo -e "${RED}✗ Failed to start PostgreSQL port-forward${NC}"
    exit 1
fi

# ScyllaDB
echo -e "${YELLOW}Port-forwarding ScyllaDB (localhost:9042)...${NC}"
kubectl port-forward -n dev svc/scylla-dev-client 9042:9042 > /dev/null 2>&1 &
SCYLLA_PID=$!
sleep 2

if ps -p $SCYLLA_PID > /dev/null; then
    echo -e "${GREEN}✓ ScyllaDB port-forward running (PID: $SCYLLA_PID)${NC}"
else
    echo -e "${RED}✗ Failed to start ScyllaDB port-forward${NC}"
    exit 1
fi

# Get database passwords
echo ""
echo "Database Credentials:"
echo "--------------------"
POSTGRES_PASSWORD=$(kubectl get secret postgresql-dev -n dev -o jsonpath='{.data.postgres-password}' 2>/dev/null | base64 -d 2>/dev/null || echo "Error getting password")
SCYLLA_PASSWORD=$(kubectl get secret scylladb-dev -n dev -o jsonpath='{.data.cassandra-password}' 2>/dev/null | base64 -d 2>/dev/null || echo "Error getting password")

echo "PostgreSQL: postgres / $POSTGRES_PASSWORD @ localhost:5432"
echo "ScyllaDB:   cassandra / $SCYLLA_PASSWORD @ localhost:9042"

# Check if .env file exists
if [ ! -f .env ]; then
    echo ""
    echo -e "${YELLOW}⚠ .env file not found${NC}"
    echo "Creating .env from .env.example..."
    cp .env.example .env
    
    # Update passwords in .env
    sed -i "s/POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$POSTGRES_PASSWORD/" .env
    sed -i "s/SCYLLA_PASSWORD=.*/SCYLLA_PASSWORD=$SCYLLA_PASSWORD/" .env
    
    echo -e "${GREEN}✓ .env file created${NC}"
    echo "Please review and edit .env if needed"
fi

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo ""
    echo "Creating Python virtual environment..."
    python3 -m venv venv
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt
    echo -e "${GREEN}✓ Dependencies installed${NC}"
else
    source venv/bin/activate
fi

# Test database connections
echo ""
echo "Testing database connections..."

# Test PostgreSQL
if nc -z localhost 5432 2>/dev/null; then
    echo -e "${GREEN}✓ PostgreSQL is reachable${NC}"
else
    echo -e "${RED}✗ PostgreSQL is not reachable${NC}"
fi

# Test ScyllaDB
if nc -z localhost 9042 2>/dev/null; then
    echo -e "${GREEN}✓ ScyllaDB is reachable${NC}"
else
    echo -e "${RED}✗ ScyllaDB is not reachable${NC}"
fi

# Start the application
echo ""
echo "=========================================="
echo "Starting FastAPI application..."
echo "=========================================="
echo ""
echo "API will be available at:"
echo "  - http://localhost:8000"
echo "  - http://10.0.0.11:8000"
echo ""
echo "Interactive API docs:"
echo "  - http://localhost:8000/docs"
echo ""
echo "To stop:"
echo "  - Press Ctrl+C to stop the API"
echo "  - Run ./stop-dev.sh to stop port-forwards"
echo ""

# Run the application
python app.py

# Cleanup on exit
trap "echo 'Cleaning up...'; pkill -f 'kubectl port-forward'; exit" INT TERM
