#!/bin/bash

# ============================================================================
# Stop Development Environment
# ============================================================================
# Stops all kubectl port-forwards for the development environment

echo "Stopping development environment..."

# Stop PostgreSQL port-forward
if pkill -f "kubectl port-forward.*postgresql-dev"; then
    echo "✓ Stopped PostgreSQL port-forward"
else
    echo "✗ No PostgreSQL port-forward running"
fi

# Stop ScyllaDB port-forward
if pkill -f "kubectl port-forward.*scylla-dev"; then
    echo "✓ Stopped ScyllaDB port-forward"
else
    echo "✗ No ScyllaDB port-forward running"
fi

echo "Done!"
