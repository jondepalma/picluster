# FastAPI Multi-Database Example
# Connects to both PostgreSQL and ScyllaDB in your K3s cluster

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import os
from datetime import datetime
import uvicorn

# Database imports
import asyncpg  # For PostgreSQL
from cassandra.cluster import Cluster, NoHostAvailable
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import SimpleStatement

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

app = FastAPI(
    title="Pi Cluster API",
    description="Example API using PostgreSQL and ScyllaDB on Raspberry Pi K3s cluster",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# CONFIGURATION
# ============================================================================

class Config:
    # PostgreSQL Configuration
    POSTGRES_HOST = os.getenv("POSTGRES_HOST", "localhost")
    POSTGRES_PORT = int(os.getenv("POSTGRES_PORT", "5432"))
    POSTGRES_DB = os.getenv("POSTGRES_DB", "devdb")
    POSTGRES_USER = os.getenv("POSTGRES_USER", "postgres")
    POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "devpassword")
    
    # ScyllaDB Configuration
    SCYLLA_HOSTS = os.getenv("SCYLLA_HOSTS", "localhost").split(",")
    SCYLLA_PORT = int(os.getenv("SCYLLA_PORT", "9042"))
    SCYLLA_KEYSPACE = os.getenv("SCYLLA_KEYSPACE", "dev_keyspace")
    SCYLLA_USER = os.getenv("SCYLLA_USER", "cassandra")
    SCYLLA_PASSWORD = os.getenv("SCYLLA_PASSWORD", "cassandra")
    
    # Application Configuration
    ENVIRONMENT = os.getenv("ENVIRONMENT", "development")
    DEBUG = os.getenv("DEBUG", "true").lower() == "true"

config = Config()

# ============================================================================
# DATABASE CONNECTIONS
# ============================================================================

# Global connection objects
pg_pool = None
scylla_session = None
scylla_cluster = None

async def init_postgres():
    """Initialize PostgreSQL connection pool"""
    global pg_pool
    try:
        pg_pool = await asyncpg.create_pool(
            host=config.POSTGRES_HOST,
            port=config.POSTGRES_PORT,
            database=config.POSTGRES_DB,
            user=config.POSTGRES_USER,
            password=config.POSTGRES_PASSWORD,
            min_size=2,
            max_size=10,
            command_timeout=60
        )
        print(f"✓ Connected to PostgreSQL at {config.POSTGRES_HOST}:{config.POSTGRES_PORT}")
        
        # Create tables if they don't exist
        async with pg_pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    email VARCHAR(100) UNIQUE NOT NULL,
                    created_at TIMESTAMP DEFAULT NOW()
                )
            """)
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS posts (
                    id SERIAL PRIMARY KEY,
                    user_id INTEGER REFERENCES users(id),
                    title VARCHAR(200) NOT NULL,
                    content TEXT,
                    created_at TIMESTAMP DEFAULT NOW()
                )
            """)
        print("✓ PostgreSQL tables initialized")
        
    except Exception as e:
        print(f"✗ Failed to connect to PostgreSQL: {e}")
        raise

def init_scylla():
    """Initialize ScyllaDB connection"""
    global scylla_cluster, scylla_session
    try:
        auth_provider = PlainTextAuthProvider(
            username=config.SCYLLA_USER,
            password=config.SCYLLA_PASSWORD
        )
        
        scylla_cluster = Cluster(
            contact_points=config.SCYLLA_HOSTS,
            port=config.SCYLLA_PORT,
            auth_provider=auth_provider,
            protocol_version=4
        )
        
        scylla_session = scylla_cluster.connect()
        print(f"✓ Connected to ScyllaDB at {config.SCYLLA_HOSTS}")
        
        # Create keyspace if it doesn't exist
        scylla_session.execute(f"""
            CREATE KEYSPACE IF NOT EXISTS {config.SCYLLA_KEYSPACE}
            WITH replication = {{'class': 'SimpleStrategy', 'replication_factor': 1}}
        """)
        
        scylla_session.set_keyspace(config.SCYLLA_KEYSPACE)
        
        # Create tables
        scylla_session.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id UUID PRIMARY KEY,
                event_type TEXT,
                user_id INT,
                data TEXT,
                timestamp TIMESTAMP
            )
        """)
        
        scylla_session.execute("""
            CREATE TABLE IF NOT EXISTS metrics (
                metric_name TEXT,
                timestamp TIMESTAMP,
                value DOUBLE,
                tags MAP<TEXT, TEXT>,
                PRIMARY KEY (metric_name, timestamp)
            ) WITH CLUSTERING ORDER BY (timestamp DESC)
        """)
        
        print("✓ ScyllaDB keyspace and tables initialized")
        
    except NoHostAvailable as e:
        print(f"✗ Failed to connect to ScyllaDB: {e}")
        raise
    except Exception as e:
        print(f"✗ ScyllaDB initialization error: {e}")
        raise

async def close_databases():
    """Close database connections"""
    global pg_pool, scylla_session, scylla_cluster
    
    if pg_pool:
        await pg_pool.close()
        print("✓ PostgreSQL connection closed")
    
    if scylla_session:
        scylla_session.shutdown()
    if scylla_cluster:
        scylla_cluster.shutdown()
        print("✓ ScyllaDB connection closed")

# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class UserCreate(BaseModel):
    username: str
    email: str

class User(BaseModel):
    id: int
    username: str
    email: str
    created_at: datetime

class PostCreate(BaseModel):
    user_id: int
    title: str
    content: str

class Post(BaseModel):
    id: int
    user_id: int
    title: str
    content: str
    created_at: datetime

class EventCreate(BaseModel):
    event_type: str
    user_id: int
    data: str

class MetricCreate(BaseModel):
    metric_name: str
    value: float
    tags: Optional[dict] = {}

# ============================================================================
# API ROUTES - PostgreSQL
# ============================================================================

@app.post("/users", response_model=User)
async def create_user(user: UserCreate):
    """Create a new user in PostgreSQL"""
    try:
        async with pg_pool.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO users (username, email) VALUES ($1, $2) RETURNING *",
                user.username, user.email
            )
            return dict(row)
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Username or email already exists")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/users", response_model=List[User])
async def get_users():
    """Get all users from PostgreSQL"""
    async with pg_pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM users ORDER BY created_at DESC")
        return [dict(row) for row in rows]

@app.get("/users/{user_id}", response_model=User)
async def get_user(user_id: int):
    """Get a specific user by ID"""
    async with pg_pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM users WHERE id = $1", user_id)
        if not row:
            raise HTTPException(status_code=404, detail="User not found")
        return dict(row)

@app.post("/posts", response_model=Post)
async def create_post(post: PostCreate):
    """Create a new post in PostgreSQL"""
    async with pg_pool.acquire() as conn:
        # Verify user exists
        user = await conn.fetchrow("SELECT id FROM users WHERE id = $1", post.user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        row = await conn.fetchrow(
            "INSERT INTO posts (user_id, title, content) VALUES ($1, $2, $3) RETURNING *",
            post.user_id, post.title, post.content
        )
        return dict(row)

@app.get("/posts", response_model=List[Post])
async def get_posts():
    """Get all posts from PostgreSQL"""
    async with pg_pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM posts ORDER BY created_at DESC")
        return [dict(row) for row in rows]

@app.get("/users/{user_id}/posts", response_model=List[Post])
async def get_user_posts(user_id: int):
    """Get all posts by a specific user"""
    async with pg_pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT * FROM posts WHERE user_id = $1 ORDER BY created_at DESC",
            user_id
        )
        return [dict(row) for row in rows]

# ============================================================================
# API ROUTES - ScyllaDB
# ============================================================================

@app.post("/events")
async def create_event(event: EventCreate):
    """Create a new event in ScyllaDB"""
    import uuid
    
    event_id = uuid.uuid4()
    timestamp = datetime.now()
    
    scylla_session.execute(
        """
        INSERT INTO events (id, event_type, user_id, data, timestamp)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (event_id, event.event_type, event.user_id, event.data, timestamp)
    )
    
    return {
        "id": str(event_id),
        "event_type": event.event_type,
        "user_id": event.user_id,
        "data": event.data,
        "timestamp": timestamp.isoformat()
    }

@app.get("/events")
async def get_events(limit: int = 100):
    """Get recent events from ScyllaDB"""
    rows = scylla_session.execute(
        f"SELECT * FROM events LIMIT {limit}"
    )
    
    return [
        {
            "id": str(row.id),
            "event_type": row.event_type,
            "user_id": row.user_id,
            "data": row.data,
            "timestamp": row.timestamp.isoformat() if row.timestamp else None
        }
        for row in rows
    ]

@app.post("/metrics")
async def create_metric(metric: MetricCreate):
    """Record a metric in ScyllaDB"""
    timestamp = datetime.now()
    
    scylla_session.execute(
        """
        INSERT INTO metrics (metric_name, timestamp, value, tags)
        VALUES (%s, %s, %s, %s)
        """,
        (metric.metric_name, timestamp, metric.value, metric.tags)
    )
    
    return {
        "metric_name": metric.metric_name,
        "timestamp": timestamp.isoformat(),
        "value": metric.value,
        "tags": metric.tags
    }

@app.get("/metrics/{metric_name}")
async def get_metrics(metric_name: str, limit: int = 100):
    """Get recent values for a specific metric"""
    rows = scylla_session.execute(
        f"""
        SELECT * FROM metrics 
        WHERE metric_name = %s 
        LIMIT {limit}
        """,
        (metric_name,)
    )
    
    return [
        {
            "metric_name": row.metric_name,
            "timestamp": row.timestamp.isoformat() if row.timestamp else None,
            "value": row.value,
            "tags": row.tags
        }
        for row in rows
    ]

# ============================================================================
# HEALTH & INFO ROUTES
# ============================================================================

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "name": "Pi Cluster API",
        "version": "1.0.0",
        "environment": config.ENVIRONMENT,
        "databases": {
            "postgresql": f"{config.POSTGRES_HOST}:{config.POSTGRES_PORT}",
            "scylladb": f"{config.SCYLLA_HOSTS}"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    health = {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "databases": {}
    }
    
    # Check PostgreSQL
    try:
        async with pg_pool.acquire() as conn:
            await conn.fetchval("SELECT 1")
        health["databases"]["postgresql"] = "connected"
    except Exception as e:
        health["databases"]["postgresql"] = f"error: {str(e)}"
        health["status"] = "unhealthy"
    
    # Check ScyllaDB
    try:
        scylla_session.execute("SELECT now() FROM system.local")
        health["databases"]["scylladb"] = "connected"
    except Exception as e:
        health["databases"]["scylladb"] = f"error: {str(e)}"
        health["status"] = "unhealthy"
    
    return health

# ============================================================================
# STARTUP & SHUTDOWN EVENTS
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Initialize database connections on startup"""
    print("=" * 60)
    print("Starting Pi Cluster API")
    print(f"Environment: {config.ENVIRONMENT}")
    print("=" * 60)
    
    await init_postgres()
    init_scylla()
    
    print("=" * 60)
    print("API is ready!")
    print(f"Docs available at: http://localhost:8000/docs")
    print("=" * 60)

@app.on_event("shutdown")
async def shutdown_event():
    """Close database connections on shutdown"""
    print("\nShutting down...")
    await close_databases()
    print("Goodbye!")

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8000,
        reload=config.DEBUG,
        log_level="info"
    )
