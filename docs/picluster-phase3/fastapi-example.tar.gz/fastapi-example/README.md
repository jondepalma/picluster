# Pi Cluster API - FastAPI with PostgreSQL and ScyllaDB

A complete example FastAPI application that connects to both PostgreSQL and ScyllaDB running in your Raspberry Pi K3s cluster.

## Features

- ✅ **PostgreSQL** - Relational data (users, posts)
- ✅ **ScyllaDB** - Time-series data (events, metrics)
- ✅ **FastAPI** - Modern async Python web framework
- ✅ **Dual deployment** - Bare-metal dev + Kubernetes production
- ✅ **Health checks** - Database connection monitoring
- ✅ **Auto-documentation** - Interactive API docs

---

## Project Structure

```
fastapi-example/
├── app.py                 # Main FastAPI application
├── requirements.txt       # Python dependencies
├── .env.example          # Environment variables template
├── Dockerfile            # Container image for deployment
├── deployment.yaml       # Kubernetes manifests
├── start-dev.sh          # Development startup script
├── stop-dev.sh           # Stop port-forwards
├── CLAUDE_CONTEXT.md     # Environment context for Claude Code
└── README.md            # This file
```

---

## Prerequisites

### On pi-worker-1 (10.0.0.11)

1. **kubectl configured:**
   ```bash
   mkdir -p ~/.kube
   scp pi@10.0.0.10:/etc/rancher/k3s/k3s.yaml ~/.kube/config
   sed -i 's/127.0.0.1/10.0.0.10/g' ~/.kube/config
   chmod 600 ~/.kube/config
   ```

2. **Python 3.11+ installed:**
   ```bash
   python3 --version  # Should be 3.11 or higher
   ```

3. **Cluster databases running:**
   ```bash
   kubectl get pods -n dev
   # Should see: postgresql-dev-0, scylla-dev-dc1-rack1-0
   ```

---

## Quick Start - Development Mode

### 1. Clone/Copy Project to pi-worker-1

```bash
# On pi-worker-1
cd ~/dev-projects
mkdir -p pi-cluster-api
cd pi-cluster-api

# Copy all files from this directory
```

### 2. Make Scripts Executable

```bash
chmod +x start-dev.sh stop-dev.sh
```

### 3. Start Development Environment

```bash
./start-dev.sh
```

This script will:
- ✅ Check kubectl configuration
- ✅ Start port-forwarding for PostgreSQL (localhost:5432)
- ✅ Start port-forwarding for ScyllaDB (localhost:9042)
- ✅ Retrieve database passwords from Kubernetes secrets
- ✅ Create Python virtual environment
- ✅ Install dependencies
- ✅ Create `.env` file with correct passwords
- ✅ Start the FastAPI application

### 4. Access the API

Open your browser to:
- **API Root:** http://localhost:8000
- **Interactive Docs:** http://localhost:8000/docs
- **Alternative Docs:** http://localhost:8000/redoc
- **Health Check:** http://localhost:8000/health

### 5. Test the API

```bash
# Create a user (PostgreSQL)
curl -X POST http://localhost:8000/users \
  -H "Content-Type: application/json" \
  -d '{"username": "alice", "email": "alice@example.com"}'

# Get all users
curl http://localhost:8000/users

# Create a post (PostgreSQL)
curl -X POST http://localhost:8000/posts \
  -H "Content-Type: application/json" \
  -d '{"user_id": 1, "title": "Hello World", "content": "My first post!"}'

# Get all posts
curl http://localhost:8000/posts

# Create an event (ScyllaDB)
curl -X POST http://localhost:8000/events \
  -H "Content-Type: application/json" \
  -d '{"event_type": "user_login", "user_id": 1, "data": "Login from 10.0.0.11"}'

# Get recent events
curl http://localhost:8000/events

# Record a metric (ScyllaDB)
curl -X POST http://localhost:8000/metrics \
  -H "Content-Type: application/json" \
  -d '{"metric_name": "cpu_usage", "value": 45.2, "tags": {"host": "pi-worker-1"}}'

# Get metric values
curl http://localhost:8000/metrics/cpu_usage
```

### 6. Stop Development Environment

```bash
# Press Ctrl+C to stop the API

# Stop port-forwards
./stop-dev.sh
```

---

## Manual Setup (Alternative)

If you prefer to set up manually:

### 1. Port-Forward Databases

```bash
# Terminal 1: PostgreSQL
kubectl port-forward -n dev svc/postgresql-dev 5432:5432

# Terminal 2: ScyllaDB
kubectl port-forward -n dev svc/scylla-dev-client 9042:9042
```

### 2. Get Database Passwords

```bash
# PostgreSQL password
kubectl get secret postgresql-dev -n dev -o jsonpath='{.data.postgres-password}' | base64 -d

# ScyllaDB password
kubectl get secret scylladb-dev -n dev -o jsonpath='{.data.cassandra-password}' | base64 -d
```

### 3. Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 4. Configure Environment

```bash
cp .env.example .env
# Edit .env and add the passwords from step 2
nano .env
```

### 5. Run the Application

```bash
python app.py
```

---

## Deploy to Kubernetes Cluster

### 1. Build Docker Image

```bash
# On pi-worker-1 (or any machine with Docker)
docker build -t your-dockerhub-username/pi-cluster-api:v1.0.0 .

# Tag as latest
docker tag your-dockerhub-username/pi-cluster-api:v1.0.0 \
            your-dockerhub-username/pi-cluster-api:latest
```

### 2. Push to Docker Hub

```bash
# Login to Docker Hub
docker login

# Push images
docker push your-dockerhub-username/pi-cluster-api:v1.0.0
docker push your-dockerhub-username/pi-cluster-api:latest
```

### 3. Update Deployment Manifest

Edit `deployment.yaml`:
```yaml
# Line 45: Update image name
image: your-dockerhub-username/pi-cluster-api:latest

# Line 107: Update domain
host: api.yourdomain.com
```

### 4. Deploy to Cluster

```bash
kubectl apply -f deployment.yaml
```

### 5. Verify Deployment

```bash
# Check pods
kubectl get pods -n dev -l app=pi-cluster-api

# Check logs
kubectl logs -n dev -l app=pi-cluster-api --tail=50

# Check service
kubectl get svc -n dev pi-cluster-api

# Check ingress
kubectl get ingress -n dev pi-cluster-api
```

### 6. Access the API

```bash
# Get Traefik LoadBalancer IP
TRAEFIK_IP=$(kubectl get svc -n traefik traefik -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

# Test via Traefik (internal)
curl -H "Host: api.yourdomain.com" http://$TRAEFIK_IP/health

# Or access via Cloudflare Tunnel (external)
curl https://api.yourdomain.com/health
```

---

## API Endpoints

### PostgreSQL (Relational Data)

#### Users
- `POST /users` - Create a new user
- `GET /users` - List all users
- `GET /users/{user_id}` - Get a specific user
- `GET /users/{user_id}/posts` - Get posts by user

#### Posts
- `POST /posts` - Create a new post
- `GET /posts` - List all posts

### ScyllaDB (Time-Series Data)

#### Events
- `POST /events` - Record an event
- `GET /events?limit=100` - Get recent events

#### Metrics
- `POST /metrics` - Record a metric
- `GET /metrics/{metric_name}?limit=100` - Get metric values

### System
- `GET /` - API information
- `GET /health` - Health check with database status

---

## Database Schemas

### PostgreSQL Tables

```sql
-- Users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Posts table
CREATE TABLE posts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    title VARCHAR(200) NOT NULL,
    content TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);
```

### ScyllaDB Tables

```cql
-- Events table
CREATE TABLE events (
    id UUID PRIMARY KEY,
    event_type TEXT,
    user_id INT,
    data TEXT,
    timestamp TIMESTAMP
);

-- Metrics table
CREATE TABLE metrics (
    metric_name TEXT,
    timestamp TIMESTAMP,
    value DOUBLE,
    tags MAP<TEXT, TEXT>,
    PRIMARY KEY (metric_name, timestamp)
) WITH CLUSTERING ORDER BY (timestamp DESC);
```

---

## Environment Variables

| Variable | Development | Production |
|----------|-------------|------------|
| `POSTGRES_HOST` | `localhost` | `postgresql-dev.dev.svc.cluster.local` |
| `POSTGRES_PORT` | `5432` | `5432` |
| `POSTGRES_DB` | `devdb` | `devdb` |
| `POSTGRES_USER` | `postgres` | `postgres` |
| `POSTGRES_PASSWORD` | From secret | From secret |
| `SCYLLA_HOSTS` | `localhost` | `scylla-dev-client.dev.svc.cluster.local` |
| `SCYLLA_PORT` | `9042` | `9042` |
| `SCYLLA_KEYSPACE` | `dev_keyspace` | `dev_keyspace` |
| `SCYLLA_USER` | `cassandra` | `cassandra` |
| `SCYLLA_PASSWORD` | From secret | From secret |
| `ENVIRONMENT` | `development` | `production` |
| `DEBUG` | `true` | `false` |

---

## Troubleshooting

### Port-forward not working

```bash
# Check if port-forwards are running
ps aux | grep "kubectl port-forward"

# Kill and restart
./stop-dev.sh
./start-dev.sh
```

### Can't connect to databases

```bash
# Test connectivity
nc -zv localhost 5432  # PostgreSQL
nc -zv localhost 9042  # ScyllaDB

# Check pods are running
kubectl get pods -n dev

# Check service endpoints
kubectl get endpoints -n dev postgresql-dev
kubectl get endpoints -n dev scylla-dev-client
```

### Application errors

```bash
# Check logs
tail -f logs.txt  # If running in background

# Or run in foreground to see output
python app.py
```

### kubectl not configured

```bash
# Re-configure kubectl
mkdir -p ~/.kube
scp pi@10.0.0.10:/etc/rancher/k3s/k3s.yaml ~/.kube/config
sed -i 's/127.0.0.1/10.0.0.10/g' ~/.kube/config
chmod 600 ~/.kube/config

# Test
kubectl get nodes
```

---

## Development Tips

### Using with VS Code Remote-SSH

1. Connect to `pi-dev` in VS Code
2. Open terminal in VS Code
3. Run `./start-dev.sh`
4. Use VS Code's integrated terminal and debugger

### Database Management

```bash
# PostgreSQL CLI
kubectl exec -it postgresql-dev-0 -n dev -- psql -U postgres -d devdb

# ScyllaDB CLI
PASSWORD=$(kubectl get secret scylladb-dev -n dev -o jsonpath='{.data.cassandra-password}' | base64 -d)
kubectl exec -it scylla-dev-dc1-rack1-0 -n dev -c scylla -- cqlsh -u cassandra -p $PASSWORD
```

### Hot Reload

The FastAPI app uses `uvicorn` with `reload=True` in development mode, so changes to `app.py` will automatically reload the server.

---

## Claude Code Integration

This project includes `CLAUDE_CONTEXT.md` which provides Claude Code with:
- Infrastructure details
- Database connection info
- Common commands
- Deployment patterns
- Troubleshooting tips

**Place `CLAUDE_CONTEXT.md` in your project root** so Claude Code can reference it when helping with development.

---

## Next Steps

1. **Add authentication** - JWT tokens, API keys
2. **Add tests** - pytest with async support
3. **Add caching** - Redis for frequently accessed data
4. **Add monitoring** - Prometheus metrics endpoint
5. **Add CI/CD** - GitHub Actions for automated deployment
6. **Add more endpoints** - Build out your API logic
7. **Production database** - Deploy to `prod` namespace with HA

---

## Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [asyncpg Documentation](https://magicstack.github.io/asyncpg/)
- [Cassandra Driver Documentation](https://docs.datastax.com/en/developer/python-driver/)
- [Kubernetes Python Client](https://github.com/kubernetes-client/python)

---

## License

MIT License - Feel free to use this as a template for your projects!
